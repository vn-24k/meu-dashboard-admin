<template>
  <div id="main-content">
      <div class="container-fluid">
          <div class="block-header">
              <bread-crumb></bread-crumb>
          </div>
          <div class="row clearfix">
              <div class="col-lg-12 col-md-12 col-sm-12">
                  <div class="card">
                      <div class="header">
                          <h2>World Map</h2>
                      </div>
                      <div class="body">
                        <div id="map" style="height: 700px; width: 100%"></div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script setup>
import BreadCrumb from '@/components/BreadCrumb'
import { ref, onMounted } from 'vue';
import "leaflet/dist/leaflet.css";
import * as L from 'leaflet';

const initialMap = ref(null);

onMounted(()=> {
  initialMap.value = L.map('map').setView([20.5937, 78.9629], 6);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, 
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(initialMap.value);
});
</script>
<style>
#map{
    z-index: 0;
}
</style>
