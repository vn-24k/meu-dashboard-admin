<template>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <BreadCrumb></BreadCrumb>
            </div>
            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Basic Validation</h2>
                        </div>
                        <div class="body">
                            <Form @submit="basicSubmit" id="basic-form" ref="form" :validation-schema="schema" v-slot="{ errors }">
                                <Field name="name" rules="required" v-slot="{ handleChange,classes }">
                                    <div class="form-group">
                                        <label>Text Input</label>
                                        <input @update:model-value="handleChange" v-model="basic.name" type="text" class="form-control" :class="classes">
                                        <span :class="{'text-danger': errors.name}">{{ errors.name }}</span>
                                    </div>
                                </Field>
    
                                <Field name="email" rules="required|email" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label>Email Input</label>
                                        <input @update:model-value="handleChange" v-model="basic.email" type="email" class="form-control" :class="classes">
                                        <span :class="{'text-danger': errors.email}">{{ errors.email }}</span>
                                    </div>
                                </Field>
    
                                <Field name="textarea" rules="required" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label>Text Area</label>
                                        <textarea class="form-control" @update:model-value="handleChange" v-model="basic.textarea" :class="classes"></textarea>
                                        <span :class="{'text-danger': errors.textarea}">{{ errors.textarea }}</span>
                                    </div>
                                </Field>
                                <div class="form-group">
                                    <label>Checkbox</label>
                                    <br/>
                                    <label class="fancy-checkbox">
                                        <input type="checkbox" name="checkbox">
                                        <span>Option 1</span>
                                    </label>
                                    <label class="fancy-checkbox">
                                        <input type="checkbox" name="checkbox">
                                        <span>Option 2</span>
                                    </label>
                                    <label class="fancy-checkbox">
                                        <input type="checkbox" name="checkbox">
                                        <span>Option 3</span>
                                    </label>
                                    <p id="error-checkbox"></p>
                                </div>
                                <div class="form-group">
                                    <label>Radio Button</label>
                                    <br />
                                    <label class="fancy-radio">
                                        <input type="radio" name="gender" value="male">
                                        <span><i></i>Male</span>
                                    </label>
                                    <label class="fancy-radio">
                                        <input type="radio" name="gender" value="female">
                                        <span><i></i>Female</span>
                                    </label>
                                    <p id="error-radio"></p>
                                </div>
                                <div class="form-group">
                                    <label for="food">Multiselect</label>
                                    <br/>
                                    <multiselect
                                        v-model="selected"
                                        :multiple="true"
                                        :options="options"
                                        label="name" 
                                        track-by="name">
                                    </multiselect>
                                    <p id="error-multiselect"></p>
                                </div>
                                <button type="submit" class="btn btn-primary">Validate</button>
                            </Form>
                        </div>  
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Advanced Validation</h2>
                        </div>
                        <div class="body">
                            <Form @submit="advancedSubmit" class="form" :validation-schema="schema" v-slot="{ errors }">
                                <Field name="input1" rules="required|min:8" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label for="text-input1">Min. 8 Characters</label>
                                        <input type="text"  class="form-control" @update:model-value="handleChange" v-model="advanced.input1" :class="classes">
                                        <span :class="{'text-danger': errors.input1}">{{ errors.input1 }}</span>
                                    </div>
                                </Field>
    
                                <Field name="input2" rules="required|alpha|min:5|max:10" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label for="text-input2">Between 5-10 Characters</label>
                                        <input type="text"  class="form-control" @update:model-value="handleChange" v-model="advanced.input2" :class="classes">
                                        <span :class="{'text-danger': errors.input2}">{{ errors.input2 }}</span>
                                    </div>
                                </Field>
    
                                <Field name="input3" rules="required|min_value:5|numeric" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label for="text-input3">Min. Number ( >= 5 )</label>
                                        <input type="text"  class="form-control" @update:model-value="handleChange" v-model="advanced.input3" :class="classes">
                                        <span :class="{'text-danger': errors.input3}">{{ errors.input3 }}</span>
                                    </div>
                                </Field>
                                <Field name="input4" rules="required|between:20,30|numeric" v-slot="{ handleChange,classes}">
                                    <div class="form-group">
                                        <label for="text-input4">Between 20-30</label>
                                        <input type="text"  class="form-control" @update:model-value="handleChange" v-model="advanced.input4" :class="classes">
                                        <span :class="{'text-danger': errors.input4}">{{ errors.input4 }}</span>
                                    </div>
                                </Field>
                                <div class="form-group">
                                    <label>Select Min. 2 Options</label>
                                    <br />
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox2">
                                        <span>Option 1</span>
                                    </label>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox2">
                                        <span>Option 2</span>
                                    </label>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox2">
                                        <span>Option 3</span>
                                    </label>
                                    <p id="error-checkbox2"></p>
                                </div>
                                <div class="form-group">
                                    <label>Select Between 1-2 Options</label>
                                    <br />
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox3" >
                                        <span>Option 1</span>
                                    </label>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox3">
                                        <span>Option 2</span>
                                    </label>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox" name="checkbox3">
                                        <span>Option 3</span>
                                    </label>
                                    <p id="error-checkbox3"></p>
                                </div>
                                <br/>
                                <button type="submit" class="btn btn-primary">Validate</button>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Form, Field } from 'vee-validate';
import BreadCrumb from'@/components/BreadCrumb.vue'
import VueMultiselect from 'vue-multiselect'
export default {
  name: "ValidationComponent",
  components: {
    Form, 
    Field,
    'Multiselect': VueMultiselect,
    BreadCrumb
  },
  data: () => ({
    selected: null,
    options: [{name:'Cheese'}, {name:'Tomatoes'}, {name:'Mozzarella'}, {name:'Mushrooms'}, {name:'Pepperoni'},{name:'Onions'}],
    advanced: {
        input1: "",
        input2: "",
        input3: "",
        input4: "",
    },
    basic: {
      email: "",
      textarea: "",
      name: ""
    }
  }),
  methods: {
    advancedSubmit() {
      console.log("Submitting to server!");
    },
    basicSubmit() {
      console.log("Submitting to server!");
    }
  }
};
</script>