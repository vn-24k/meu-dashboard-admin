<template>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
               <bread-crumb></bread-crumb>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="body">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="To">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Subject">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="CC">
                                </div>
                            </form>
                            <hr>
                            <div>
                                <ckeditor :editor="editor" v-model="content" :config="editorConfig"></ckeditor>
                            </div>
                            <div class="m-t-30">
                                <button type="button" class="btn btn-success mr-1">Send Message</button>
                                <button type="button" class="btn btn-secondary mr-1">Draft</button>
                                <router-link to="/app/app-inbox" class="btn btn-outline-secondary mr-1">Cancel</router-link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import BreadCrumb from '@/components/BreadCrumb'
export default {
    name:'ComposeComponent',
    components: {
        BreadCrumb
    },
    data() {
        return {
            editor: ClassicEditor,
            content: "<h3>hi,</h3> <h4>we are Wrraptheme</h4> <p></p>"
        };
    }
}
</script>
<style scoped>

</style>