<template>
    <div class="card weather2">
        <div class="body city-selected">
            <div class="row">
                <div class="col-12">
                    <div class="city"><span>City:</span> San Francisco</div>
                    <div class="night">Day - 12:07 PM</div>
                </div>
                <div class="info col-7">
                    <div class="temp">
                        <h2>34°</h2>
                    </div>
                </div>
                <div class="icon col-5">
                    <i class="wi wi-day-cloudy-windy"></i>
                </div>
            </div>
        </div>
        <table class="table table-striped m-b-0">
            <tbody>
                <tr>
                    <td>Land area</td>
                    <td class="font-medium">121.4 km²</td>
                </tr>
                <tr>
                    <td>Humidity</td>
                    <td class="font-medium">73%</td>
                </tr>
                <tr>
                    <td>Pressure</td>
                    <td class="font-medium">25.56 in</td>
                </tr>
                <tr>
                    <td>Population</td>
                    <td class="font-medium">8.65 lakhs</td>
                </tr>
                <tr>
                    <td>Ceiling</td>
                    <td class="font-medium">25280 ft</td>
                </tr>
            </tbody>
        </table>
        <Carousel :autoplay="2000" :wrap-around="true" :itemsToShow="3">
            <Slide v-for="(item) in data" :key="item.id">
                <div class="col-12 carousel__item">
                    <ul class="row days-list list-unstyled">
                        <li class="day col-12">
                            <p>{{item.name}}</p>
                            <i :class="item.icon"></i>
                        </li>
                    </ul>
                </div>
            </Slide>
        </Carousel>
    </div>
</template>
<script>
import { Carousel, Slide } from 'vue3-carousel';
import '/node_modules/vue3-carousel/dist/carousel.css'
export default {
    name:'Weather1Component',
    components: {
        Carousel,
        Slide
    },
    data() {
        return {
            data: [
                {id: 1,icon:'wi wi-day-hail',name:'Monday'}, 
                {id: 2,icon:'wi wi-day-lightning',name:'Tuesday'}, 
                {id: 3,icon:'wi wi-day-storm-showers',name:'Wednesday'},
                {id: 4,icon:'wi wi-day-hail',name:'Thursday'},
                {id: 5,icon:'wi wi-showers',name:'Friday'},
                {id: 6,icon:'wi wi-day-sunny',name:'Saturday'}
            ]
        }
    },
}
</script>
<style scoped>

</style>