<template>
    <div class="card">
       <div class="header">
           <h2>Total Revenue</h2>
           <card_actions></card_actions>
       </div>
       <div class="body text-center">
           <h4 class="margin-0">Total Sale</h4>
           <h6 class="m-b-0">2,45,124</h6>
           <v-chart class="revenueDoughnut mr-auto ml-auto" :option="doughnutoptions" autoresize />
           <v-chart class="revenueBar" :option="baroptions" autoresize />
           <h6 class="m-b-0">Weekly Earnings</h6>
       </div>
   </div>
</template>
<script>
import card_actions from '@/components/core/CardActions.vue';
export default {
   name: 'AnaliticalRevenue',
    components: {
       card_actions,
   },
   props: {
       doughnutoptions: Object,
       baroptions:Object,
   }
}
</script>
<style scoped>
.revenueBar{
   width: 100%;
   height: 80px;
}
.revenueDoughnut{
   width: 100%;
   height: 150px;
}
</style>