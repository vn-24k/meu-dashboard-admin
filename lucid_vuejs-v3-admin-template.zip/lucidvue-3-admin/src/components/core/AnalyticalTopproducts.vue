<template>
    <div class="card">
       <div class="header">
           <h2>Top Products</h2>
           <card_actions></card_actions>
       </div>
       <div class="body">
           <v-chart class="chartist" :option="options" autoresize />
       </div>
   </div>
</template>
<script>
import card_actions from '@/components/core/CardActions.vue';
export default {
   name: 'AnalyticalTopproducts',
    components: {
       card_actions,
   },
   props: {
       options: Object,
   }
}
</script>
<style scoped>
.chartist{
   width:100%;
   height: 292px;
}
</style>