<template>
    <div class="card single_post">
        <div class="body pb-0">
            <h3 class="m-t-0 m-b-5"><a href="blog-details.html">All photographs are accurate. None of them is the truth</a></h3>
            <ul class="meta">
                <li><a href="javascript:void(0);"><i class="icon-user text-primary"></i>Posted By: John Smith</a></li>
                <li><a href="javascript:void(0);"><i class="icon-tag text-success"></i>Photography</a></li>
                <li><a href="javascript:void(0);"><i class="icon-bubbles text-warning"></i>Comments: 3</a></li>
            </ul>
        </div>                    
        <div class="body">
            <div class="img-post m-b-15">
                <Carousel :autoplay="2000" :wrap-around="true" :itemsToShow="1">
                    <Slide  v-for="(image) in images" :key="image.id">
                        <div class="carousel__item">
                            <img class="d-block img-fluid" :src="getImage(image.url)" alt="First slide">
                        </div>
                    </Slide>
                    <template #addons>
                        <Navigation>
                            <template #prev><i class='fa fa-angle-left'></i></template>
                            <template #next><i class='fa fa-angle-right'></i></template>
                        </Navigation>
                    </template>
                </Carousel>
            </div>
            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal</p>
             <router-link to="/blogs/blog-details" class="btn btn-info m-t-20">Read More</router-link>                      
        </div>
    </div>
</template>
<script>
const { Carousel,Navigation, Slide } = require('vue3-carousel')
import '/node_modules/vue3-carousel/dist/carousel.css'
export default {
    name:'PostCarousel',
    components: {
        Carousel,
        Navigation,
        Slide
    },
    data() {
        return {
            images: [{id: 1,url:'blog-page-1.jpg'}, {id: 2,url:'blog-page-3.jpg'}, {id: 3,url:'blog-page-2.jpg'}]
        }
    },
    methods: {
        getImage(imagePath) {
            return require(`@/assets/blog/${imagePath}`);
        }
    }
}
</script>
<style scoped>

</style>